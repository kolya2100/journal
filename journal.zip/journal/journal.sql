-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 17 2021 г., 01:57
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `journal`
--

-- --------------------------------------------------------

--
-- Структура таблицы `curator_notations`
--

CREATE TABLE `curator_notations` (
  `curator_notations_id` int NOT NULL,
  `curator_notations_desc` text NOT NULL,
  `teacher_id` int NOT NULL,
  `semester` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `curator_notations`
--

INSERT INTO `curator_notations` (`curator_notations_id`, `curator_notations_desc`, `teacher_id`, `semester`) VALUES
(3, 'Some body was told me the world is gonna roll me\r\nThe new Life ', 1, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `educational_work`
--

CREATE TABLE `educational_work` (
  `educational_work_id` int NOT NULL,
  `educational_work_date` date NOT NULL,
  `educational_work_teacher_id` int NOT NULL,
  `educational_work_grade` text NOT NULL,
  `group_id` int NOT NULL,
  `semester` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `educational_work`
--

INSERT INTO `educational_work` (`educational_work_id`, `educational_work_date`, `educational_work_teacher_id`, `educational_work_grade`, `group_id`, `semester`) VALUES
(1, '2021-05-05', 2, 'Best Practice numero dos', 12171, 4),
(3, '2021-05-12', 3, 'fhmcjgymjg', 12171, 4),
(4, '2021-05-21', 1, 'favrvbdzrh srh snrybsrgezrga egegwers', 12171, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `group`
--

CREATE TABLE `group` (
  `group_id` int NOT NULL,
  `group_spec` int NOT NULL,
  `group_curator` int NOT NULL,
  `semester` int DEFAULT NULL,
  `cource` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `group`
--

INSERT INTO `group` (`group_id`, `group_spec`, `group_curator`, `semester`, `cource`) VALUES
(12171, 1, 1, NULL, 4),
(21351, 4, 4, NULL, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `group_special`
--

CREATE TABLE `group_special` (
  `special_id` int NOT NULL,
  `special_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `group_special`
--

INSERT INTO `group_special` (`special_id`, `special_name`) VALUES
(1, '121 \"Розробка програмного забезпечення\"'),
(2, '071 \"Облік і оподаткування\" '),
(3, '075 \"Маркетинг\"'),
(4, '076 \"Підприємництво, торгівля та біржова діяльність\"'),
(5, '133 \"Галузеве машинобудування\"'),
(6, '141 \"Електроенергетика, електротехніка та електромеханіка\"'),
(7, '275 \"Транспортні технологіЇ\"');

-- --------------------------------------------------------

--
-- Структура таблицы `group_subjects`
--

CREATE TABLE `group_subjects` (
  `group_id` int NOT NULL,
  `subject_id` int NOT NULL,
  `teacher_id` int NOT NULL,
  `semester` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `group_subjects`
--

INSERT INTO `group_subjects` (`group_id`, `subject_id`, `teacher_id`, `semester`) VALUES
(12171, 3, 1, 1),
(12171, 2, 2, 1),
(12171, 1, 3, 1),
(12171, 1, 1, 2),
(12171, 3, 1, 2),
(12171, 2, 2, 2),
(12171, 1, 1, 3),
(12171, 2, 2, 3),
(12171, 3, 3, 3),
(12171, 3, 1, 4),
(12171, 2, 2, 4),
(12171, 1, 3, 4),
(21351, 1, 1, 4),
(21351, 2, 2, 4),
(21351, 1, 3, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `hobby_group`
--

CREATE TABLE `hobby_group` (
  `hobby_group_id` int NOT NULL,
  `hobby_group_occupation` text NOT NULL,
  `hobby_work_student_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `marks`
--

CREATE TABLE `marks` (
  `mark_id` int NOT NULL,
  `mark_subject_grade` int NOT NULL,
  `mark_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `marks`
--

INSERT INTO `marks` (`mark_id`, `mark_subject_grade`, `mark_name`) VALUES
(5, 20, 'Контрольный модуль 1'),
(6, 2, 'Оцінка за пару'),
(7, 4, 'Срс'),
(8, 12, 'Para'),
(9, 20, 'Km1'),
(10, 8, 'Оцінка за пару'),
(11, 20, 'KM1'),
(12, 12, 'asfhbaswef');

-- --------------------------------------------------------

--
-- Структура таблицы `months`
--

CREATE TABLE `months` (
  `month_id` int NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `months`
--

INSERT INTO `months` (`month_id`, `name`) VALUES
(1, 'Вересень'),
(2, 'Жовтень'),
(3, 'Листопад'),
(4, 'Грудень'),
(5, 'Січень'),
(6, 'Лютий'),
(7, 'Березень'),
(8, 'Квітень'),
(9, 'Травень'),
(10, 'Червень');

-- --------------------------------------------------------

--
-- Структура таблицы `parents`
--

CREATE TABLE `parents` (
  `parents_id` int NOT NULL,
  `father_full_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `father_number` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `father_job` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `mother_full_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `mother_phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `mother_job` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `parents_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `parents`
--

INSERT INTO `parents` (`parents_id`, `father_full_name`, `father_number`, `father_job`, `mother_full_name`, `mother_phone`, `mother_job`, `parents_address`) VALUES
(1, 'Batya', '12314', 'afasef', 'Matya', '123124', 'awfewad', 'asfdwef'),
(2, 'Some', '123', 'SOme2', 'Emos', '321', 'Emos2', 'SOme ADdreSs');

-- --------------------------------------------------------

--
-- Структура таблицы `parents_talk`
--

CREATE TABLE `parents_talk` (
  `parents_talk_id` int NOT NULL,
  `parents_talk_date` date NOT NULL,
  `description` text NOT NULL,
  `group_id` int NOT NULL,
  `semester` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `promotions_and_reprimands`
--

CREATE TABLE `promotions_and_reprimands` (
  `prom_id` int NOT NULL,
  `prom_date` date NOT NULL,
  `prom_order_id` int NOT NULL,
  `prom_descriprion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `promotions_and_reprimands`
--

INSERT INTO `promotions_and_reprimands` (`prom_id`, `prom_date`, `prom_order_id`, `prom_descriprion`) VALUES
(1, '2021-04-26', 1241241, 'Чемпион ващета '),
(2, '2021-06-01', 34124, 'ColdBloodGuy'),
(3, '2021-05-04', 123, 'fawefwae fwef a'),
(4, '2021-03-31', 4123, 'wefegearavrv'),
(5, '2021-04-26', 2342, 'efwefwqagqта '),
(6, '2021-04-26', 23421231, 'dsfgahrsegaergawr'),
(7, '2021-04-26', 2342, 'efwefwqagqта ');

-- --------------------------------------------------------

--
-- Структура таблицы `prom_student`
--

CREATE TABLE `prom_student` (
  `prom_id` int NOT NULL,
  `student_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `prom_student`
--

INSERT INTO `prom_student` (`prom_id`, `student_id`) VALUES
(1, 37),
(2, 37),
(3, 37),
(4, 29),
(5, 29),
(6, 37),
(7, 29);

-- --------------------------------------------------------

--
-- Структура таблицы `remarks`
--

CREATE TABLE `remarks` (
  `remark_id` int NOT NULL,
  `remark_date` date NOT NULL,
  `remark_inspector_name` varchar(255) NOT NULL,
  `remark_disc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `skips`
--

CREATE TABLE `skips` (
  `skip_id` int NOT NULL,
  `student_id` int NOT NULL,
  `total_skips` int NOT NULL,
  `resonable_skips` int NOT NULL,
  `month` int NOT NULL,
  `week` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `skips`
--

INSERT INTO `skips` (`skip_id`, `student_id`, `total_skips`, `resonable_skips`, `month`, `week`) VALUES
(6, 37, 12, 12, 1, '12-12'),
(7, 29, 30, 23, 1, '13-12'),
(8, 29, 48, 42, 1, '12-12');

-- --------------------------------------------------------

--
-- Структура таблицы `student`
--

CREATE TABLE `student` (
  `student_id` int NOT NULL,
  `student_full_name` varchar(255) NOT NULL,
  `student_phone` varchar(255) NOT NULL,
  `student_address` varchar(255) NOT NULL,
  `student_stud_form` int NOT NULL,
  `student_is_contract` int NOT NULL,
  `student_mail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `student_sex` int NOT NULL,
  `student_nation` int DEFAULT NULL,
  `student_birth` date NOT NULL,
  `student_graduate` int NOT NULL,
  `student_grant` tinyint(1) NOT NULL,
  `student_parents` int DEFAULT NULL,
  `semester` int DEFAULT NULL,
  `student_group_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `student`
--

INSERT INTO `student` (`student_id`, `student_full_name`, `student_phone`, `student_address`, `student_stud_form`, `student_is_contract`, `student_mail`, `student_sex`, `student_nation`, `student_birth`, `student_graduate`, `student_grant`, `student_parents`, `semester`, `student_group_id`) VALUES
(26, 'Коваленко Микола Да', '+380380380380', 'Да', 1, 2, 'some@some.com', 1, 1, '2021-04-26', 1, 0, 2, 1, 12171),
(27, 'Коваленко Микола Да', '+380380380380', 'Да', 1, 2, 'some@some.com', 1, 1, '2021-04-26', 1, 0, 2, 2, 12171),
(28, 'Коваленко Микола Да', '+380380380380', 'Да', 1, 2, 'some@some.com', 1, 1, '2021-04-26', 1, 0, 2, 3, 12171),
(29, 'Коваленко Микола Да', '+380380380380', 'Да', 1, 2, 'some@some.com', 1, 1, '2021-04-26', 1, 0, 2, 4, 12171),
(30, 'Коваленко Микола Да', '+380380380380', 'Да', 1, 2, 'some@some.com', 1, 1, '2021-04-26', 1, 0, 2, 5, 12171),
(31, 'Коваленко Микола Да', '+380380380380', 'Да', 1, 2, 'some@some.com', 1, 1, '2021-04-26', 1, 0, 2, 6, 12171),
(32, 'Коваленко Микола Да', '+380380380380', 'Да', 1, 2, 'some@some.com', 1, 1, '2021-04-26', 1, 0, 2, 7, 12171),
(33, 'Коваленко Микола Нет', '+380380380380', 'Нет', 1, 2, 'some@some.com', 1, 1, '2021-04-26', 1, 0, 2, 8, 12171),
(34, 'Баранов Андрій Олегович', '+32742398423', 'нцуфі', 1, 2, 'stemproket@gmail.com', 1, 1, '2021-04-07', 2, 0, NULL, 1, 12171),
(35, 'Баранов Андрій Олегович', '+32742398423', 'нцуфі', 1, 2, 'stemproket@gmail.com', 1, 1, '2021-04-07', 2, 0, NULL, 2, 12171),
(36, 'Баранов Андрій Олегович', '+32742398423', 'нцуфі', 1, 2, 'stemproket@gmail.com', 1, 1, '2021-04-07', 2, 0, NULL, 3, 12171),
(37, 'Баранов Андрій Олегович', '+32742398423', 'нцуфі', 1, 2, 'stemproket@gmail.com', 1, 1, '2021-04-07', 2, 0, NULL, 4, 12171),
(38, 'Баранов Андрій Олегович', '+32742398423', 'нцуфі', 1, 2, 'stemproket@gmail.com', 1, 1, '2021-04-07', 2, 0, NULL, 5, 12171),
(39, 'Баранов Андрій Олегович', '+32742398423', 'нцуфі', 1, 2, 'stemproket@gmail.com', 1, 1, '2021-04-07', 2, 0, NULL, 6, 12171),
(40, 'Баранов Андрій Олегович', '+32742398423', 'нцуфі', 1, 2, 'stemproket@gmail.com', 1, 1, '2021-04-07', 2, 0, NULL, 7, 12171),
(41, 'Баранов Андрій Олегович', '+32742398423', 'нцуфі', 1, 2, 'stemproket@gmail.com', 1, 1, '2021-04-07', 2, 0, NULL, 8, 12171);

-- --------------------------------------------------------

--
-- Структура таблицы `student_contract`
--

CREATE TABLE `student_contract` (
  `student_is_contract_id` int NOT NULL,
  `field_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `student_contract`
--

INSERT INTO `student_contract` (`student_is_contract_id`, `field_name`) VALUES
(1, 'Контракт'),
(2, 'Бюджет');

-- --------------------------------------------------------

--
-- Структура таблицы `student_graduate_choose`
--

CREATE TABLE `student_graduate_choose` (
  `student_graduate_id` int NOT NULL,
  `graduate_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `student_graduate_choose`
--

INSERT INTO `student_graduate_choose` (`student_graduate_id`, `graduate_name`) VALUES
(1, '9 класів'),
(2, '10 класів'),
(3, '11 класів');

-- --------------------------------------------------------

--
-- Структура таблицы `student_nation_choose`
--

CREATE TABLE `student_nation_choose` (
  `student_nation_id` int NOT NULL,
  `nation_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `student_nation_choose`
--

INSERT INTO `student_nation_choose` (`student_nation_id`, `nation_name`) VALUES
(1, 'Українець');

-- --------------------------------------------------------

--
-- Структура таблицы `student_sex_choose`
--

CREATE TABLE `student_sex_choose` (
  `student_sex_id` int NOT NULL,
  `sex_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `student_sex_choose`
--

INSERT INTO `student_sex_choose` (`student_sex_id`, `sex_name`) VALUES
(1, 'Юнак'),
(2, 'Дівчина');

-- --------------------------------------------------------

--
-- Структура таблицы `student_studying_form`
--

CREATE TABLE `student_studying_form` (
  `student_stud_form_id` int NOT NULL,
  `studying_form` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `student_studying_form`
--

INSERT INTO `student_studying_form` (`student_stud_form_id`, `studying_form`) VALUES
(1, 'Денна'),
(2, 'Заочна'),
(3, 'Вільне відвідування');

-- --------------------------------------------------------

--
-- Структура таблицы `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int NOT NULL,
  `subject_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject_name`) VALUES
(1, 'Українська мова'),
(2, 'Математика'),
(3, 'Українська література');

-- --------------------------------------------------------

--
-- Структура таблицы `subject_mark`
--

CREATE TABLE `subject_mark` (
  `subject_id` int NOT NULL,
  `mark_id` int DEFAULT NULL,
  `student_id` int NOT NULL,
  `semester` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `subject_mark`
--

INSERT INTO `subject_mark` (`subject_id`, `mark_id`, `student_id`, `semester`) VALUES
(3, 5, 29, 4),
(3, 6, 29, 4),
(3, 7, 29, 4),
(2, 8, 27, 2),
(2, 9, 27, 2),
(3, 10, 37, 4),
(2, 11, 37, 4),
(3, 12, 29, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `subject_teacher`
--

CREATE TABLE `subject_teacher` (
  `id` int NOT NULL,
  `subject_id` int NOT NULL,
  `teacher_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `subject_teacher`
--

INSERT INTO `subject_teacher` (`id`, `subject_id`, `teacher_id`) VALUES
(10, 1, 1),
(11, 3, 1),
(12, 2, 2),
(13, 1, 3),
(14, 3, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int NOT NULL,
  `teacher_full_name` varchar(255) NOT NULL,
  `teacher_login` varchar(255) DEFAULT NULL,
  `teacher_password` varchar(255) DEFAULT NULL,
  `teacher_pic` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `teacher_full_name`, `teacher_login`, `teacher_password`, `teacher_pic`) VALUES
(1, 'Хищенко Тетяна Вікторіна', 'hishenko', '123', NULL),
(2, 'Опята Людмила Іванівна', NULL, NULL, NULL),
(3, 'Лілія Петрівна', NULL, NULL, NULL),
(4, 'sudfbsd', 'log', '123', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `teacher_visit`
--

CREATE TABLE `teacher_visit` (
  `teacher_visit_id` int NOT NULL,
  `teacher_visit_date` date NOT NULL,
  `teacher_id` int NOT NULL,
  `subject_id` int NOT NULL,
  `teacher_visit_desc` text NOT NULL,
  `group_id` int NOT NULL,
  `semester` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `curator_notations`
--
ALTER TABLE `curator_notations`
  ADD PRIMARY KEY (`curator_notations_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Индексы таблицы `educational_work`
--
ALTER TABLE `educational_work`
  ADD PRIMARY KEY (`educational_work_id`),
  ADD KEY `educational_work_ibfk_1` (`educational_work_teacher_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Индексы таблицы `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `group_ibfk_1` (`group_curator`),
  ADD KEY `group_spec` (`group_spec`);

--
-- Индексы таблицы `group_special`
--
ALTER TABLE `group_special`
  ADD PRIMARY KEY (`special_id`);

--
-- Индексы таблицы `group_subjects`
--
ALTER TABLE `group_subjects`
  ADD KEY `group_id` (`group_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Индексы таблицы `hobby_group`
--
ALTER TABLE `hobby_group`
  ADD PRIMARY KEY (`hobby_group_id`);

--
-- Индексы таблицы `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`mark_id`);

--
-- Индексы таблицы `months`
--
ALTER TABLE `months`
  ADD PRIMARY KEY (`month_id`);

--
-- Индексы таблицы `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`parents_id`);

--
-- Индексы таблицы `parents_talk`
--
ALTER TABLE `parents_talk`
  ADD PRIMARY KEY (`parents_talk_id`),
  ADD KEY `parents_talk_ibfk_1` (`group_id`);

--
-- Индексы таблицы `promotions_and_reprimands`
--
ALTER TABLE `promotions_and_reprimands`
  ADD PRIMARY KEY (`prom_id`);

--
-- Индексы таблицы `prom_student`
--
ALTER TABLE `prom_student`
  ADD KEY `prom_id` (`prom_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Индексы таблицы `remarks`
--
ALTER TABLE `remarks`
  ADD PRIMARY KEY (`remark_id`);

--
-- Индексы таблицы `skips`
--
ALTER TABLE `skips`
  ADD PRIMARY KEY (`skip_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `month` (`month`);

--
-- Индексы таблицы `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `student_stud_form` (`student_stud_form`),
  ADD KEY `student_sex` (`student_sex`),
  ADD KEY `student_parents` (`student_parents`),
  ADD KEY `student_nation` (`student_nation`),
  ADD KEY `student_is_contract` (`student_is_contract`),
  ADD KEY `student_graduate` (`student_graduate`),
  ADD KEY `student_group_id` (`student_group_id`);

--
-- Индексы таблицы `student_contract`
--
ALTER TABLE `student_contract`
  ADD PRIMARY KEY (`student_is_contract_id`);

--
-- Индексы таблицы `student_graduate_choose`
--
ALTER TABLE `student_graduate_choose`
  ADD PRIMARY KEY (`student_graduate_id`);

--
-- Индексы таблицы `student_nation_choose`
--
ALTER TABLE `student_nation_choose`
  ADD PRIMARY KEY (`student_nation_id`);

--
-- Индексы таблицы `student_sex_choose`
--
ALTER TABLE `student_sex_choose`
  ADD PRIMARY KEY (`student_sex_id`);

--
-- Индексы таблицы `student_studying_form`
--
ALTER TABLE `student_studying_form`
  ADD PRIMARY KEY (`student_stud_form_id`);

--
-- Индексы таблицы `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Индексы таблицы `subject_mark`
--
ALTER TABLE `subject_mark`
  ADD KEY `subject_mark_ibfk_1` (`mark_id`),
  ADD KEY `subject_mark_ibfk_2` (`subject_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Индексы таблицы `subject_teacher`
--
ALTER TABLE `subject_teacher`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Индексы таблицы `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Индексы таблицы `teacher_visit`
--
ALTER TABLE `teacher_visit`
  ADD PRIMARY KEY (`teacher_visit_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `group_id` (`group_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `curator_notations`
--
ALTER TABLE `curator_notations`
  MODIFY `curator_notations_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `educational_work`
--
ALTER TABLE `educational_work`
  MODIFY `educational_work_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `group_special`
--
ALTER TABLE `group_special`
  MODIFY `special_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `hobby_group`
--
ALTER TABLE `hobby_group`
  MODIFY `hobby_group_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `marks`
--
ALTER TABLE `marks`
  MODIFY `mark_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `months`
--
ALTER TABLE `months`
  MODIFY `month_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `parents`
--
ALTER TABLE `parents`
  MODIFY `parents_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `parents_talk`
--
ALTER TABLE `parents_talk`
  MODIFY `parents_talk_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `promotions_and_reprimands`
--
ALTER TABLE `promotions_and_reprimands`
  MODIFY `prom_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `remarks`
--
ALTER TABLE `remarks`
  MODIFY `remark_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `skips`
--
ALTER TABLE `skips`
  MODIFY `skip_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT для таблицы `student_contract`
--
ALTER TABLE `student_contract`
  MODIFY `student_is_contract_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `student_graduate_choose`
--
ALTER TABLE `student_graduate_choose`
  MODIFY `student_graduate_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `student_nation_choose`
--
ALTER TABLE `student_nation_choose`
  MODIFY `student_nation_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `student_sex_choose`
--
ALTER TABLE `student_sex_choose`
  MODIFY `student_sex_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `student_studying_form`
--
ALTER TABLE `student_studying_form`
  MODIFY `student_stud_form_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `subject_teacher`
--
ALTER TABLE `subject_teacher`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `teacher_visit`
--
ALTER TABLE `teacher_visit`
  MODIFY `teacher_visit_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `curator_notations`
--
ALTER TABLE `curator_notations`
  ADD CONSTRAINT `curator_notations_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `educational_work`
--
ALTER TABLE `educational_work`
  ADD CONSTRAINT `educational_work_ibfk_1` FOREIGN KEY (`educational_work_teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `educational_work_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `group`
--
ALTER TABLE `group`
  ADD CONSTRAINT `group_ibfk_1` FOREIGN KEY (`group_curator`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `group_ibfk_2` FOREIGN KEY (`group_spec`) REFERENCES `group_special` (`special_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `group_subjects`
--
ALTER TABLE `group_subjects`
  ADD CONSTRAINT `group_subjects_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `group_subjects_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `group_subjects_ibfk_3` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `parents_talk`
--
ALTER TABLE `parents_talk`
  ADD CONSTRAINT `parents_talk_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `prom_student`
--
ALTER TABLE `prom_student`
  ADD CONSTRAINT `prom_student_ibfk_1` FOREIGN KEY (`prom_id`) REFERENCES `promotions_and_reprimands` (`prom_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prom_student_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `skips`
--
ALTER TABLE `skips`
  ADD CONSTRAINT `skips_ibfk_1` FOREIGN KEY (`month`) REFERENCES `months` (`month_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`student_stud_form`) REFERENCES `student_studying_form` (`student_stud_form_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`student_sex`) REFERENCES `student_sex_choose` (`student_sex_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_3` FOREIGN KEY (`student_parents`) REFERENCES `parents` (`parents_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_4` FOREIGN KEY (`student_nation`) REFERENCES `student_nation_choose` (`student_nation_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_5` FOREIGN KEY (`student_is_contract`) REFERENCES `student_contract` (`student_is_contract_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_6` FOREIGN KEY (`student_graduate`) REFERENCES `student_graduate_choose` (`student_graduate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_7` FOREIGN KEY (`student_group_id`) REFERENCES `group` (`group_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `subject_mark`
--
ALTER TABLE `subject_mark`
  ADD CONSTRAINT `subject_mark_ibfk_1` FOREIGN KEY (`mark_id`) REFERENCES `marks` (`mark_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subject_mark_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subject_mark_ibfk_3` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `subject_teacher`
--
ALTER TABLE `subject_teacher`
  ADD CONSTRAINT `subject_teacher_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subject_teacher_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `teacher_visit`
--
ALTER TABLE `teacher_visit`
  ADD CONSTRAINT `teacher_visit_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `teacher_visit_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `teacher_visit_ibfk_3` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
