<?
session_start();
$connect = mysqli_connect('localhost',
'root',  'root', 'lr8');
if(!$connect)
{
	die("Error");
}