<?php

require_once '../vendor/autoload.php';

$document = new \PhpOffice\PhpWord\TemplateProcessor('./reiting.docx');

$uploadDir =  __DIR__;
$outputFile = 's.docx';

$uploadFile = $uploadDir . '\\' . basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile);

$number_date = $_POST['number_date'];
$mounth = $_POST['mounth'];
$year = $_POST['year'];
$first_date = $_POST['first_date'];
$second_date = $_POST['second_date'];
$otdel = $_POST['otdel'];
$group = $_POST['group'];
$name = $_POST['name'];
$form_school = $_POST['form_school'];
$arg_ball = $_POST['arg_ball'];
$dop_ball = $_POST['dop_ball'];
$total_ball = $_POST['total_ball'];
$dicrpition = $_POST['dicrpition'];
$nr = $_POST['nr'];
$zav_otdel1 = $_POST['zav_otdel1'];
$zav_otdel2 = $_POST['zav_otdel2'];
$zav_otdel3 = $_POST['zav_otdel3'];
$booker = $_POST['booker'];
$komisiya = $_POST['komisiya'];
$styd_rada1 = $_POST['styd_rada1'];
$styd_rada2 = $_POST['styd_rada2'];
$styd_rada3 = $_POST['styd_rada3'];
$styd_rada4 = $_POST['styd_rada4'];
$styd_rada5 = $_POST['styd_rada5'];
$styd_rada6 = $_POST['styd_rada6'];
$styd_rada7 = $_POST['styd_rada7'];

$document->setValue('number_date', $number_date);
$document->setValue('mounth', $mounth);
$document->setValue('year', $year);
$document->setValue('season', $season);
$document->setValue('first_date', $first_date);
$document->setValue('second_date', $second_date);
$document->setValue('otdel', $otdel);
$document->setValue('group', $group);
$document->setValue('name', $name);
$document->setValue('form_school', $form_school);
$document->setValue('arg_ball', $arg_ball);
$document->setValue('dop_ball', $dop_ball);
$document->setValue('total_ball', $total_ball);
$document->setValue('dicrpition', $dicrpition);
$document->setValue('nr', $nr);
$document->setValue('zav_otdel1', $zav_otdel1);
$document->setValue('zav_otdel2', $zav_otdel2);
$document->setValue('zav_otdel3', $zav_otdel3);
$document->setValue('booker', $booker);
$document->setValue('komisiya', $komisiya);
$document->setValue('styd_rada1', $styd_rada1);
$document->setValue('styd_rada2', $styd_rada2);
$document->setValue('styd_rada3', $styd_rada3);
$document->setValue('styd_rada4', $styd_rada4);
$document->setValue('styd_rada5', $styd_rada5);
$document->setValue('styd_rada6', $styd_rada6);
$document->setValue('styd_rada7', $styd_rada7);

$document->saveAs($outputFile);
// Имя скачиваемого файла
$downloadFile = $outputFile;

// Контент-тип означающий скачивание
header("Content-Type: application/octet-stream");

// Размер в байтах
header("Accept-Ranges: bytes");

// Размер файла
header("Content-Length: ".filesize($downloadFile));

// Расположение скачиваемого файла
header("Content-Disposition: attachment; filename=".$downloadFile);

// Прочитать файл
readfile($downloadFile);


unlink($uploadFile);
unlink($outputFile);