<?php

require_once '../vendor/autoload.php';

$document = new \PhpOffice\PhpWord\TemplateProcessor('./klopot.docx');

$uploadDir =  __DIR__;
$outputFile = 'Клопіт.docx';

$uploadFile = $uploadDir . '\\' . basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile);

$mounth = $_POST['mounth'];
$year = $_POST['year'];
$group = $_POST['group'];
$full_name_kurator_klopot = $_POST['full_name_kurator_klopot'];
$season = $_POST['season'];
$first_date = $_POST['first_date'];
$second_date = $_POST['second_date'];
$name_klopot = $_POST['name_klopot'];
$form_school_klopot = $_POST['form_school_klopot'];
$avg_ball_klopot = $_POST['avg_ball_klopot'];
$dop_ball_klopot = $_POST['dop_ball_klopot'];
$total_ball_klopot = $_POST['total_ball_klopot'];
$dicrpition_klopot = $_POST['dicrpition_klopot'];
$dicrpition_good = $_POST['dicrpition_good'];
$full_date = $_POST['full_date'];



$document->setValue('mounth', $mounth);
$document->setValue('year', $year);
$document->setValue('group', $group);
$document->setValue('full_name_kurator_klopot', $full_name_kurator_klopot);
$document->setValue('season', $season);
$document->setValue('first_date', $first_date);
$document->setValue('second_date', $second_date);
$document->setValue('name_klopot', $name_klopot);
$document->setValue('form_school_klopot', $form_school_klopot);
$document->setValue('avg_ball_klopot', $avg_ball_klopot);
$document->setValue('dop_ball_klopot', $dop_ball_klopot);
$document->setValue('total_ball_klopot', $total_ball_klopot);
$document->setValue('dicrpition_klopot', $dicrpition_klopot);
$document->setValue('dicrpition_good', $dicrpition_good);
$document->setValue('full_date', $full_date);


$document->saveAs($outputFile);
// Имя скачиваемого файла
$downloadFile = $outputFile;

// Контент-тип означающий скачивание
header("Content-Type: application/octet-stream");

// Размер в байтах
header("Accept-Ranges: bytes");

// Размер файла
header("Content-Length: ".filesize($downloadFile));

// Расположение скачиваемого файла
header("Content-Disposition: attachment; filename=".$downloadFile);

// Прочитать файл
readfile($downloadFile);


unlink($uploadFile);
unlink($outputFile);