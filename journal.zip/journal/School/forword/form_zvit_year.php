<?php

require_once '../vendor/autoload.php';

$document = new \PhpOffice\PhpWord\TemplateProcessor('./form_zvit_for_year.docx');

$uploadDir =  __DIR__;
$outputFile = 'Звіт за рік.docx';

$uploadFile = $uploadDir . '\\' . basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile);


$first_date = $_POST['first_date'];
$second_date = $_POST['second_date'];
$name_kurator = $_POST['name_kurator'];
$name_course = $_POST['name_course'];
$group = $_POST['group'];
$col_student_in_group = $_POST['col_student_in_group'];
$begin_year = $_POST['begin_year'];
$end_year = $_POST['end_year'];
$free = $_POST['free'];
$free_coins = $_POST['free_coins'];
$leave = $_POST['leave'];
$leave_for_school_year = $_POST['leave_for_school_year'];
$stupied = $_POST['stupied'];
$next_univer = $_POST['next_univer'];
$other = $_POST['other'];
$visiting_lessons = $_POST['visiting_lessons'];
$visiting_hour_for_year = $_POST['visiting_hour_for_year'];
$visiting_hour_for_first = $_POST['visiting_hour_for_first'];
$visiting_hour_for_second = $_POST['visiting_hour_for_second'];
$lost_hour = $_POST['lost_hour'];
$all_the_time = $_POST['all_the_time'];
$povazna = $_POST['povazna'];
$nepovazna = $_POST['nepovazna'];
$propysk_on_one_student = $_POST['propysk_on_one_student'];
$propysk = $_POST['propysk'];
$progyl = $_POST['progyl'];
$progyl_lastname = $_POST['progyl_lastname'];
$successufully = $_POST['successufully'];
$kol_student_stud = $_POST['kol_student_stud'];
$five = $_POST['five'];
$four_five = $_POST['four_five'];
$three = $_POST['three'];
$stupied_for_session = $_POST['stupied_for_session'];
$not_allowed = $_POST['not_allowed'];
$avg_ball_all_group = $_POST['avg_ball_all_group'];
$all_successefull = $_POST['all_successefull'];
$qualitative_indicator = $_POST['qualitative_indicator'];
$have_debt = $_POST['have_debt'];
$for_first_semestr_with_lessons = $_POST['for_first_semestr_with_lessons'];
$for_second_semestr_with_lessons = $_POST['for_second_semestr_with_lessons'];
$zaebalo = $_POST['zaebalo'];
$nezadovil_ball_first = $_POST['nezadovil_ball_first'];
$nezadovil_ball_second = $_POST['nezadovil_ball_second'];
$nezadovil_ball_year = $_POST['nezadovil_ball_year'];
$lastname_and_lessons = $_POST['lastname_and_lessons'];
$zahid_for_perfomance = $_POST['zahid_for_perfomance'];
$class_hour = $_POST['class_hour'];
$all_class_hour = $_POST['all_class_hour'];
$interasting_theme_class_hour = $_POST['interasting_theme_class_hour'];
$open_class_hour = $_POST['open_class_hour'];
$control_practic = $_POST['control_practic'];
$control_practic_lessons = $_POST['control_practic_lessons'];
$name_practic_time = $_POST['name_practic_time'];
$visiting_practic = $_POST['visiting_practic'];
$group_participation = $_POST['group_participation'];
$individyal_job = $_POST['individyal_job'];
$composition_of_the_parent_commitet = $_POST['composition_of_the_parent_commitet'];
$parents_tematic = $_POST['parents_tematic'];
$visiting_parents = $_POST['visiting_parents'];
$lastname_teacher = $_POST['lastname_teacher'];
$lastname_activist = $_POST['lastname_activist'];
$robbery = $_POST['robbery'];
$money_help = $_POST['money_help'];
$sirota = $_POST['sirota'];
$Chornobil = $_POST['Chornobil'];
$war = $_POST['war'];
$internally_person = $_POST['internally_person'];
$disabled = $_POST['disabled'];
$Zakon_Ukrain = $_POST['Zakon_Ukrain'];
$help_states = $_POST['help_states'];
$other_reason = $_POST['other_reason'];
$full_name_kurator = $_POST['full_name_kurator'];



$document->setValue('first_date', $first_date);
$document->setValue('second_date', $second_date);
$document->setValue('name_kurator', $name_kurator);
$document->setValue('name_course', $name_course);
$document->setValue('group', $group);
$document->setValue('col_student_in_group', $col_student_in_group);
$document->setValue('begin_year', $begin_year);
$document->setValue('end_year', $end_year);
$document->setValue('free', $free);
$document->setValue('free_coins', $free_coins);
$document->setValue('leave', $leave);
$document->setValue('leave_for_school_year', $leave_for_school_year);
$document->setValue('stupied', $stupied);
$document->setValue('next_univer', $next_univer);
$document->setValue('other', $other);
$document->setValue('visiting_lessons', $visiting_lessons);
$document->setValue('visiting_hour_for_year', $visiting_hour_for_year);
$document->setValue('visiting_hour_for_first', $visiting_hour_for_first);
$document->setValue('visiting_hour_for_second', $visiting_hour_for_second);
$document->setValue('lost_hour', $lost_hour);
$document->setValue('all_the_time', $all_the_time);
$document->setValue('povazna', $povazna);
$document->setValue('nepovazna', $nepovazna);
$document->setValue('propysk_on_one_student', $propysk_on_one_student);
$document->setValue('propysk', $propysk);
$document->setValue('progyl', $progyl);
$document->setValue('progyl_lastname', $progyl_lastname);
$document->setValue('successufully', $successufully);
$document->setValue('kol_student_stud', $kol_student_stud);
$document->setValue('five', $five);
$document->setValue('four_five', $four_five);
$document->setValue('three', $three);
$document->setValue('stupied_for_session', $stupied_for_session);
$document->setValue('not_allowed', $not_allowed);
$document->setValue('avg_ball_all_group', $avg_ball_all_group);
$document->setValue('all_successefull', $all_successefull);
$document->setValue('qualitative_indicator', $qualitative_indicator);
$document->setValue('have_debt', $have_debt);
$document->setValue('for_first_semestr_with_lessons', $for_first_semestr_with_lessons);
$document->setValue('for_second_semestr_with_lessons', $for_second_semestr_with_lessons);
$document->setValue('nezadovil_ball_year', $nezadovil_ball_year);
$document->setValue('lastname_and_lessons', $lastname_and_lessons);
$document->setValue('zahid_for_perfomance', $zahid_for_perfomance);
$document->setValue('class_hour', $class_hour);
$document->setValue('all_class_hour', $all_class_hour);
$document->setValue('interasting_theme_class_hour', $interasting_theme_class_hour);
$document->setValue('open_class_hour', $open_class_hour);
$document->setValue('control_practic', $control_practic);
$document->setValue('control_practic_lessons', $control_practic_lessons);
$document->setValue('name_practic_time', $name_practic_time);
$document->setValue('visiting_practic', $visiting_practic);
$document->setValue('group_participation', $group_participation);
$document->setValue('individyal_job', $individyal_job);
$document->setValue('composition_of_the_parent_commitet', $composition_of_the_parent_commitet);
$document->setValue('parents_tematic', $parents_tematic);
$document->setValue('visiting_parents', $visiting_parents);
$document->setValue('lastname_teacher', $lastname_teacher);
$document->setValue('lastname_activist', $lastname_activist);
$document->setValue('robbery', $robbery);
$document->setValue('money_help', $money_help);
$document->setValue('sirota', $sirota);
$document->setValue('Chornobil', $Chornobil);
$document->setValue('war', $war);
$document->setValue('internally_person', $internally_person);
$document->setValue('disabled', $disabled);
$document->setValue('Zakon_Ukrain', $Zakon_Ukrain);
$document->setValue('help_states', $help_states);
$document->setValue('other_reason', $other_reason);
$document->setValue('full_name_kurator', $full_name_kurator);


$document->saveAs($outputFile);
// Имя скачиваемого файла
$downloadFile = $outputFile;

// Контент-тип означающий скачивание
header("Content-Type: application/octet-stream");

// Размер в байтах
header("Accept-Ranges: bytes");

// Размер файла
header("Content-Length: ".filesize($downloadFile));

// Расположение скачиваемого файла
header("Content-Disposition: attachment; filename=".$downloadFile);

// Прочитать файл
readfile($downloadFile);


unlink($uploadFile);
unlink($outputFile);