<?
session_start();
$connect = mysqli_connect('localhost',
'root',  'root', 'school');
if(!$connect)
{
	die("Error");
}