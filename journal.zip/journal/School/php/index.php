<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/main_css/style.css">
	<title>Document</title>
</head>
<body>
<form action="vender/signin.php" method="POST" enctype="multipart/form/data">
	<label for="">Логин</label>
	<input type="text" name="login" placeholder="Введите свой логин"><br>
	<label for="">Пароль</label>
	<input type="password"  name="password" placeholder="Введите свой пароль">
<button>Войти</button>
<p>У вас нет аккаунта? - <a href="/register.php"> Зарегестрируйся!!</a></p>
<p>
	<? if($_SESSION['message'])
	{
		echo '<p class="msg">' . $_SESSION['message'] . '</p>';
	}
unset($_SESSION['message']);
?>
</form>

</body>
