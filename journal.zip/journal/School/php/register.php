<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style.css">
	<title>Document</title>
</head>
<body>
<form action="vender/signup.php" method="POST">
	<label for="label" align="justify-content">ФИО</label>
	<input type="text" name="full_name" placeholder="Введите свое полное имя"><br>


	<label for="label" align="justify-content">Логин</label>
	<input type="text" name="login" placeholder="Введите свой логин"><br>
	<label for="label" align="justify-content">Почта</label>
	<input type="email" name="email" placeholder="Введите свою почту"><br>
	<label for="label" align="justify-content">Пароль</label>
	<input type="password" name="password" placeholder="Введите свой пароль">
	<label for="label" align="justify-content">Подтверждение пароля</label>
	<input type="password" name="password_confirm" placeholder="Подтвердите свой пароль">

<button>Войти</button>
<p>У вас уже есть аккаун? - <a href="index.php">Авторизируйтесь</a></p>
<p>
	<? if($_SESSION['message'])
	{
		echo '<p class="msg">' . $_SESSION['message'] . '</p>';
	}
unset($_SESSION['message']);
?>
</form>

</body>
</html>