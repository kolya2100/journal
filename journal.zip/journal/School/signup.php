<?
session_start();
require_once 'connect.php';
$full_name = $_POST['full_name'];
$login = $_POST['login'];
$email = $_POST['email'];
$password = $_POST['password'];
$password_confirm = $_POST['password_confirm'];
$query = mysqli_query($connect, "SELECT COUNT(*) FROM `user` WHERE `login` = '$login'");

if (mysqli_num_rows($query) > 0) {
    $_SESSION['message'] = 'Пользователь с таким логином уже существует!';
    header('Location: ../register.php');
}
if ($password === $password_confirm) {


$password = md5($password);
	mysqli_query($connect, "INSERT INTO `user` (`id`, `full_name`,
		`login`, `email`, `password`, `avatar`) VALUES (NULL, '$full_name', '$login', '$email', '$password', '$image')");

$_SESSION['message'] = 'Регистрация прошла успешно';
	 header('Location:../index.php');
	$query = mysqli_query($connect, "SELECT COUNT(*) FROM `user` WHERE `login` = '$login'");
}

// if (mysqli_num_rows($query) > 0) {
//     $_SESSION['message'] = 'Пользователь с таким логином уже существует!';
//     header('Location: ../register.php');
// }
// }else{
// 	$_SESSION['message'] = 'Пароли не совпадают';
// 	header('Location:../register.php');
// }